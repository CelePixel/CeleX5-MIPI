#!/bin/bash

sudo apt-get install libusb-1.0-0-dev

sudo cp ./API/libCeleDriver.so /usr/local/lib/

